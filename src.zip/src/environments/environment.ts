export const environment = {
    production: false,
    firebase: {
      apiKey: "AIzaSyB14RbmX0xoY6V11RrinbyozH9zO0h5i0s",
      authDomain: "dom-bez-wtopy.web.app",
      projectId: "dom-bez-wtopy",
      storageBucket: "twoj-projekt.appspot.com",
      messagingSenderId: "twoj-sender-id",
      appId: "twoj-app-id",
      measurementId: "twoj-measurement-id" // opcjonalnie
    }
  };