export const environment = {
    production: true,
    firebase: {
      apiKey: "twoj-api-key",
      authDomain: "twoj-projekt.firebaseapp.com",
      projectId: "twoj-projekt",
      storageBucket: "twoj-projekt.appspot.com",
      messagingSenderId: "twoj-sender-id",
      appId: "twoj-app-id",
      measurementId: "twoj-measurement-id" // opcjonalnie
    }
  };