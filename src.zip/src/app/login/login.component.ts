import { Component, inject } from '@angular/core';
import { AuthService } from '../services/auth.service';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router, RouterModule } from '@angular/router';

@Component({
  standalone: true,
  selector: 'app-login',
  imports: [CommonModule, FormsModule, RouterModule],
  templateUrl: './login.component.html',
  styleUrl: './login.component.scss'
})
export class LoginComponent {
  email = '';
  password = '';
  showPassword = false;
  router = inject(Router);
  auth = inject(AuthService);

  login() {
    this.auth.login(this.email, this.password)
      .then(() => this.router.navigate(['/'])) // lub gdzie chcesz przekierować
      .catch(err => console.error('❌ Błąd logowania', err));
  }

  togglePasswordVisibility() {
    this.showPassword = !this.showPassword;
    const passwordField = document.querySelector('[name="password"]') as HTMLInputElement;
    passwordField.type = this.showPassword ? 'text' : 'password';
  }
}
