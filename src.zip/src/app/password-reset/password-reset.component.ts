import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { FormsModule, NgForm } from '@angular/forms';
import { AuthService } from '../services/auth.service';

@Component({
  selector: 'app-password-reset',
  templateUrl: './password-reset.component.html',
  standalone: true,
  imports: [FormsModule]
})
export class PasswordResetComponent {
  email: string = '';
  emailSent: boolean = false;
  isLoading: boolean = false;
  errorMessage: string | null = null;

  constructor(
    private authService: AuthService,
    public router: Router
  ) { }

  sendResetLink(form: NgForm) {
    if (form.invalid) return;

    this.isLoading = true;
    this.errorMessage = null;

    this.authService.sendPasswordResetEmail(this.email)
      .then(() => {
        this.emailSent = true;
        this.isLoading = false;
      })
      .catch(error => {
        console.error('Error sending reset link:', error);
        this.errorMessage = this.getErrorMessage(error.code);
        this.isLoading = false;
      });
  }

  private getErrorMessage(code: string): string {
    const errorMap: Record<string, string> = {
      'auth/user-not-found': 'Użytkownik o podanym emailu nie istnieje',
      'auth/invalid-email': 'Nieprawidłowy format emaila',
      'auth/too-many-requests': 'Zbyt wiele prób, spróbuj później',
      default: 'Wystąpił nieoczekiwany błąd'
    };

    return errorMap[code] || errorMap.default;
  }
}