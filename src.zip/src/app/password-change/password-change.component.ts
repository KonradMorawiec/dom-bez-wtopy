import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { NgForm } from '@angular/forms';
import { AuthService } from '../services/auth.service';

@Component({
  selector: 'app-password-change',
  templateUrl: './password-change.component.html',
  standalone: true
})
export class PasswordChangeComponent implements OnInit {
  newPassword: string = '';
  confirmPassword: string = '';
  passwordChanged: boolean = false;
  isLoading: boolean = false;
  errorMessage: string | null = null;
  private token: string | null = null;

  constructor(
    private route: ActivatedRoute,
    private authService: AuthService,
    private router: Router
  ) { }

  ngOnInit() {
    this.token = this.route.snapshot.queryParamMap.get('token');
    if (!this.token) {
      this.errorMessage = 'Brak tokenu resetującego';
    }
  }

  passwordsValid(): boolean {
    return this.newPassword === this.confirmPassword &&
      this.newPassword.length >= 6;
  }

  changePassword(form: NgForm) {
    if (form.invalid || !this.token) return;

    this.isLoading = true;
    this.errorMessage = null;

    this.authService.confirmPasswordReset(this.token, this.newPassword)
      .then(() => {
        this.passwordChanged = true;
        this.isLoading = false;
      })
      .catch(error => {
        console.error('Error changing password:', error);
        this.errorMessage = this.getErrorMessage(error.code);
        this.isLoading = false;
      });
  }

  private getErrorMessage(code: string): string {
    const errorMap: Record<string, string> = {
      'auth/expired-action-code': 'Link wygasł, wygeneruj nowy',
      'auth/invalid-action-code': 'Nieprawidłowy link resetujący',
      'auth/user-disabled': 'Konto zostało dezaktywowane',
      'auth/user-not-found': 'Użytkownik nie istnieje',
      'auth/weak-password': 'Hasło musi mieć co najmniej 6 znaków',
      default: 'Wystąpił błąd podczas zmiany hasła'
    };

    return errorMap[code] || errorMap.default;
  }
}